console.log("running")

async function getData(){
  const dataFile = 'data.json';
  const request = new Request(dataFile);

  const response = await fetch(request);
  const data = await response.json();

  // console.log(superHeroes)
  startScript(data)

}

getData();

function startScript(data){
  //
  console.log(data)
  let characters = Object.keys(data);
  console.log(characters);
  for (let i = 0; i < characters.length; i++){
    let charEntry = document.createElement("div");
    charEntry.className = "characterEntry"
    // charEntry.style.textAlign = "center";

    let char  = characters[i];
    let charData = data[char];
    console.log(char);
    console.log(charData);

    let p = document.createElement("p");
    p.className = "character";
    p.innerHTML = char;
    charEntry.appendChild(p)
    // loop over appearance
    for (let j = 0; j < charData.appearance.length; j++){
      console.log(charData.appearance[j]);
      let appear = charData.appearance[j]
      let drawing = appear.drawing_path;
      let img = document.createElement("img");
      img.src = drawing;
      img.className = "strokes";
      document.body.appendChild(img);
      img.style.height = "100px";
      // img.style.textAlign = "center";
    }
    document.body.appendChild(p);
  }
}
